Option Explicit

If WScript.Arguments.Count = 0 Then
    WScript.Echo "Please provide the folder path as an argument."
    WScript.Quit 1
End If

Dim folderPath, shell, fso, scriptFolder, batFilePath, cmd
folderPath = WScript.Arguments(0)
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

scriptFolder = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
batFilePath = scriptFolder & "\emailopener.bat"

If Not fso.FileExists(batFilePath) Then
    WScript.Echo "The batch file could not be found: " & batFilePath
    WScript.Quit 1
End If

If fso.FileExists(scriptFolder & "\exit.txt") Then
    fso.DeleteFile scriptFolder & "\exit.txt", True
End If

cmd = "cmd.exe /c cd /d """ & scriptFolder & """ && """ & batFilePath & """ """ & folderPath & """"
shell.Run cmd, 0, False
