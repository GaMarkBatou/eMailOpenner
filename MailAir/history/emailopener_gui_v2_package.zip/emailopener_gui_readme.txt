Email mappafigyelo GUI v2

Inditas:
1. Csomagold ki a zipet egy vegleges mappaba.
2. Inditsd az emailopener_gui.cmd fajlt.

Javitott pontok:
- A GUI PowerShell/WinForms alapu, ezert a karakterek stabilabban jelennek meg.
- A naplo mar nem log ki az ablakbol, gorgetheto mezoben jelenik meg.
- Minimalizalaskor az ablak az ertesitesi teruletre tud rejtodni.
- Dupla kattintas a jobb also sarokban levo ikonon: visszanyitas.
- Jobb klikk az ikonon: Megnyitas / Figyeles inditasa / Leallitas / Kilepes.
- A Windowszal automatikus inditas tovabbra is kapcsolhato.
- Saját ikon kerult a csomagba: emailopener.ico.

Megjegyzes:
A regi HTA felulet nem tud megbizhatoan rendszertray ikont kezelni, ezert a tray funkciohoz PowerShell WinForms GUI keszult.
