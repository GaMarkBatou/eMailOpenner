Email mappafigyelo GUI - v3

Inditas:
1. Csomagold ki a ZIP teljes tartalmat egy mappaba.
2. Inditsd el ezt: emailopener_gui.vbs

Fontos:
- A v3 mar nem indit lathato CMD ablakot.
- A minimalizalas / talcaikon funkcio kikerult.
- A programnak van sajat ikonja: emailopener.ico
- A Windowszal indulast a GUI-ban lehet ki-be kapcsolni.

Mukodes:
- Valaszd ki a figyelendo mappat.
- Kattints a Figyeles inditasa gombra.
- Az uj .eml es .msg fajlokat megnyitja, majd a processed almappaba helyezi.
- Leallitas gombbal a figyeles megall.
- Ablak bezarasakor a figyeles is leall.

Fajlok:
- emailopener_gui.vbs: ablak nelkuli indito
- emailopener_gui.ps1: grafikus felulet
- emailopener.bat: mappafigyelo motor
- emailopener.ico: ikon
