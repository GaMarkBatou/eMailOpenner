Option Explicit
Dim shell, fso, scriptDir, ps1, args, i, startupArg
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = scriptDir & "\emailopener_gui.ps1"
startupArg = ""
For i = 0 To WScript.Arguments.Count - 1
    If LCase(WScript.Arguments(i)) = "startup" Then startupArg = " -Startup"
Next
args = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File """ & ps1 & """" & startupArg
shell.CurrentDirectory = scriptDir
shell.Run args, 0, False
