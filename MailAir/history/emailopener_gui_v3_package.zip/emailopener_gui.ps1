# Email mappafigyelo GUI
# Inditas: emailopener_gui.vbs

param([switch]$Startup)

if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-STA','-File',('"{0}"' -f $PSCommandPath)) -WindowStyle Hidden
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$AppDir = Split-Path -Parent $PSCommandPath
$BatPath = Join-Path $AppDir 'emailopener.bat'
$VbsPath = Join-Path $AppDir 'emailopener_gui.vbs'
$ConfigPath = Join-Path $AppDir 'emailopener_config.ini'
$ExitPath = Join-Path $AppDir 'exit.txt'
$IconPath = Join-Path $AppDir 'emailopener.ico'
$StartupLinkPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'Email mappafigyelo.lnk'
$script:MonitorProcess = $null

function Get-AppIcon {
    if (Test-Path $IconPath) { return New-Object System.Drawing.Icon($IconPath) }
    return [System.Drawing.SystemIcons]::Application
}

function Add-Log([string]$Message) {
    $stamp = Get-Date -Format 'HH:mm:ss'
    $logBox.AppendText("[$stamp] $Message`r`n")
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
}

function Save-Config {
    $lines = @(
        'folder=' + $folderText.Text,
        'autostart=' + $(if ($autostartCheck.Checked) { '1' } else { '0' })
    )
    Set-Content -Path $ConfigPath -Value $lines -Encoding UTF8
}

function Load-Config {
    if (-not (Test-Path $ConfigPath)) { return }
    foreach ($line in Get-Content $ConfigPath -Encoding UTF8) {
        $p = $line.IndexOf('=')
        if ($p -lt 1) { continue }
        $key = $line.Substring(0,$p)
        $val = $line.Substring($p+1)
        switch ($key) {
            'folder' { $folderText.Text = $val }
        }
    }
}

function Set-Status([bool]$Running) {
    if ($Running) {
        $statusLabel.Text = 'Fut'
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(22,101,52)
        $startButton.Enabled = $false
        $stopButton.Enabled = $true
    } else {
        $statusLabel.Text = 'Leallitva'
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(153,27,27)
        $startButton.Enabled = $true
        $stopButton.Enabled = $false
    }
}

function Start-Monitor {
    $folder = $folderText.Text.Trim()
    if ($folder.Length -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Eloszor valassz ki egy figyelendo mappat.','Hianyzo mappa','OK','Warning') | Out-Null
        return
    }
    if (-not (Test-Path $folder -PathType Container)) {
        [System.Windows.Forms.MessageBox]::Show("A megadott mappa nem letezik:`r`n$folder",'Hibas mappa','OK','Error') | Out-Null
        return
    }
    if (-not (Test-Path $BatPath)) {
        [System.Windows.Forms.MessageBox]::Show("Nem talalhato az emailopener.bat:`r`n$BatPath",'Hianyzo fajl','OK','Error') | Out-Null
        return
    }
    if ($script:MonitorProcess -and -not $script:MonitorProcess.HasExited) {
        Add-Log 'A figyeles mar fut.'
        return
    }
    Save-Config
    if (Test-Path $ExitPath) { Remove-Item $ExitPath -Force -ErrorAction SilentlyContinue }
    $cmd = "/c cd /d `"$AppDir`" && `"$BatPath`" `"$folder`""
    $script:MonitorProcess = Start-Process -FilePath 'cmd.exe' -ArgumentList $cmd -WindowStyle Hidden -PassThru
    Set-Status $true
    Add-Log "Figyeles elinditva: $folder"
}

function Stop-Monitor {
    if ($script:MonitorProcess -and -not $script:MonitorProcess.HasExited) {
        Set-Content -Path $ExitPath -Value 'stop' -Encoding ASCII
        Add-Log 'Leallitas kert. A figyelo par masodpercen belul kilep.'
    } else {
        Add-Log 'A figyeles nem fut.'
    }
    Set-Status $false
}

function Create-StartupShortcut {
    try {
        if (-not (Test-Path $VbsPath)) { throw 'Nem talalhato az emailopener_gui.vbs indito.' }
        $wsh = New-Object -ComObject WScript.Shell
        $lnk = $wsh.CreateShortcut($StartupLinkPath)
        $lnk.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
        $lnk.Arguments = '//B //Nologo "' + $VbsPath + '" startup'
        $lnk.WorkingDirectory = $AppDir
        if (Test-Path $IconPath) { $lnk.IconLocation = $IconPath }
        $lnk.Save()
        Add-Log 'Windows automatikus inditas bekapcsolva.'
    } catch {
        $autostartCheck.Checked = $false
        Add-Log ('HIBA: Nem sikerult beallitani az automatikus inditast: ' + $_.Exception.Message)
    }
}

function Remove-StartupShortcut {
    try {
        if (Test-Path $StartupLinkPath) { Remove-Item $StartupLinkPath -Force }
        Add-Log 'Windows automatikus inditas kikapcsolva.'
    } catch {
        Add-Log ('HIBA: Nem sikerult torolni az automatikus inditast: ' + $_.Exception.Message)
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Email mappafigyelo'
$form.Size = New-Object System.Drawing.Size(640,565)
$form.MinimumSize = New-Object System.Drawing.Size(640,540)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',9)
$form.BackColor = [System.Drawing.Color]::FromArgb(243,245,247)
$form.Icon = Get-AppIcon

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Email mappafigyelo'
$title.Font = New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(18,18)
$title.Size = New-Object System.Drawing.Size(500,28)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = '.eml es .msg fajlok automatikus megnyitasa egy figyelt mappabol.'
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(85,98,115)
$subtitle.Location = New-Object System.Drawing.Point(20,50)
$subtitle.Size = New-Object System.Drawing.Size(580,20)
$form.Controls.Add($subtitle)

$folderGroup = New-Object System.Windows.Forms.GroupBox
$folderGroup.Text = 'Figyelendo mappa'
$folderGroup.Location = New-Object System.Drawing.Point(18,85)
$folderGroup.Size = New-Object System.Drawing.Size(588,110)
$form.Controls.Add($folderGroup)

$folderText = New-Object System.Windows.Forms.TextBox
$folderText.Location = New-Object System.Drawing.Point(16,28)
$folderText.Size = New-Object System.Drawing.Size(462,26)
$folderText.Font = New-Object System.Drawing.Font('Consolas',9)
$folderGroup.Controls.Add($folderText)

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = 'Tallozas'
$browseButton.Location = New-Object System.Drawing.Point(490,27)
$browseButton.Size = New-Object System.Drawing.Size(82,28)
$folderGroup.Controls.Add($browseButton)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'A feldolgozott fajlok a kivalasztott mappan beluli processed almappaba kerulnek.'
$hint.ForeColor = [System.Drawing.Color]::FromArgb(85,98,115)
$hint.Location = New-Object System.Drawing.Point(16,67)
$hint.Size = New-Object System.Drawing.Size(550,22)
$folderGroup.Controls.Add($hint)

$controlGroup = New-Object System.Windows.Forms.GroupBox
$controlGroup.Text = 'Vezerles'
$controlGroup.Location = New-Object System.Drawing.Point(18,208)
$controlGroup.Size = New-Object System.Drawing.Size(588,118)
$form.Controls.Add($controlGroup)

$statusText = New-Object System.Windows.Forms.Label
$statusText.Text = 'Allapot:'
$statusText.Location = New-Object System.Drawing.Point(16,28)
$statusText.Size = New-Object System.Drawing.Size(60,22)
$controlGroup.Controls.Add($statusText)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'Leallitva'
$statusLabel.Location = New-Object System.Drawing.Point(76,28)
$statusLabel.Size = New-Object System.Drawing.Size(130,22)
$statusLabel.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$controlGroup.Controls.Add($statusLabel)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = 'Figyeles inditasa'
$startButton.Location = New-Object System.Drawing.Point(16,62)
$startButton.Size = New-Object System.Drawing.Size(125,30)
$controlGroup.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = 'Leallitas'
$stopButton.Location = New-Object System.Drawing.Point(150,62)
$stopButton.Size = New-Object System.Drawing.Size(92,30)
$controlGroup.Controls.Add($stopButton)

$saveButton = New-Object System.Windows.Forms.Button
$saveButton.Text = 'Mentes'
$saveButton.Location = New-Object System.Drawing.Point(252,62)
$saveButton.Size = New-Object System.Drawing.Size(85,30)
$controlGroup.Controls.Add($saveButton)

$autostartCheck = New-Object System.Windows.Forms.CheckBox
$autostartCheck.Text = 'Induljon el automatikusan a Windowszal'
$autostartCheck.Location = New-Object System.Drawing.Point(355,66)
$autostartCheck.Size = New-Object System.Drawing.Size(220,22)
$controlGroup.Controls.Add($autostartCheck)

$logGroup = New-Object System.Windows.Forms.GroupBox
$logGroup.Text = 'Naplo'
$logGroup.Location = New-Object System.Drawing.Point(18,340)
$logGroup.Size = New-Object System.Drawing.Size(588,175)
$form.Controls.Add($logGroup)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Location = New-Object System.Drawing.Point(16,26)
$logBox.Size = New-Object System.Drawing.Size(556,130)
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = 'Vertical'
$logBox.BackColor = [System.Drawing.Color]::FromArgb(16,24,40)
$logBox.ForeColor = [System.Drawing.Color]::FromArgb(209,213,219)
$logBox.Font = New-Object System.Drawing.Font('Consolas',9)
$logGroup.Controls.Add($logBox)

$browseButton.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Valaszd ki a figyelendo mappat'
    if ($folderText.Text -and (Test-Path $folderText.Text -PathType Container)) { $dlg.SelectedPath = $folderText.Text }
    if ($dlg.ShowDialog() -eq 'OK') {
        $folderText.Text = $dlg.SelectedPath
        Save-Config
        Add-Log ('Mappa beallitva: ' + $dlg.SelectedPath)
    }
})
$startButton.Add_Click({ Start-Monitor })
$stopButton.Add_Click({ Stop-Monitor })
$saveButton.Add_Click({ Save-Config; Add-Log 'Beallitasok mentve.' })
$autostartCheck.Add_CheckedChanged({ if ($autostartCheck.Checked) { Create-StartupShortcut } else { Remove-StartupShortcut }; Save-Config })
$form.Add_FormClosing({
    Save-Config
    if ($script:MonitorProcess -and -not $script:MonitorProcess.HasExited) {
        Set-Content -Path $ExitPath -Value 'stop' -Encoding ASCII
    }
})

Load-Config
$autostartCheck.Checked = Test-Path $StartupLinkPath
Set-Status $false
if (-not (Test-Path $BatPath)) { Add-Log ('HIBA: Nem talalhato az emailopener.bat ebben a mappaban: ' + $AppDir); $startButton.Enabled = $false }
if ($Startup -and $autostartCheck.Checked) { Start-Monitor }

[void]$form.ShowDialog()
