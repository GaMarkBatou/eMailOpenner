@echo off
setlocal enabledelayedexpansion

if "%~1"=="" (
    echo Please provide the folder path as an argument.
    exit /b 1
)

set "folder=%~1"
set "subfolder=%folder%\processed"
set "exitfile=%CD%\exit.txt"

if exist "%exitfile%" del "%exitfile%" >nul 2>nul
if not exist "%folder%" exit /b 2
if not exist "%subfolder%" mkdir "%subfolder%" >nul 2>nul

rem Existing files at startup are moved to processed, so only newly arriving files open automatically.
for %%f in ("%folder%\*.eml") do if exist "%%~ff" move /y "%%~ff" "%subfolder%\" >nul 2>nul
for %%f in ("%folder%\*.msg") do if exist "%%~ff" move /y "%%~ff" "%subfolder%\" >nul 2>nul

:loop
if exist "%exitfile%" (
    del "%exitfile%" >nul 2>nul
    exit /b 0
)

for %%f in ("%folder%\*.eml") do if exist "%%~ff" (
    copy /b "%%~ff" "%subfolder%\" >nul 2>nul
    if exist "%subfolder%\%%~nxf" (
        del "%%~ff" >nul 2>nul
        start "" "%subfolder%\%%~nxf"
    )
)

for %%f in ("%folder%\*.msg") do if exist "%%~ff" (
    copy /b "%%~ff" "%subfolder%\" >nul 2>nul
    if exist "%subfolder%\%%~nxf" (
        del "%%~ff" >nul 2>nul
        start "" "%subfolder%\%%~nxf"
    )
)

timeout /t 3 /nobreak >nul
goto loop
