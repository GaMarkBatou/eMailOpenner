Email mappafigyelo - HTA GUI v10
=================================

Cel
---
A program egy kivalasztott mappat figyel. Ha .eml vagy .msg fajlt talal, atmasolja a processed almappaba, torli az eredetit, majd megnyitja az atmasolt fajlt.

Inditas
-------
A GUI inditasa:

  emailopener_gui.hta

Ha duplakattintasra nem nyilik meg, hasznald ezt:

  emailopener_gui_start.vbs

A GUI bezarhato. A figyeles ettol meg tovabb fut a hatterben, ha elotte el lett inditva.

Alap hasznalat
--------------
1. Inditsd el az emailopener_gui.hta fajlt.
2. Tallozas gombbal valaszd ki a figyelendo mappat.
3. Kattints a Figyeles inditasa gombra.
4. A GUI bezarhato, a figyeles tovabb fut.
5. Leallitashoz nyisd meg ujra a GUI-t, majd kattints a Leallitas gombra.

Windowszal inditas
------------------
A jelolonegyzet neve:

  Windowszal induljon a rejtett figyeles, GUI nelkul

Bekapcsolas utan Windows indulaskor nem a GUI indul el, hanem csak a rejtett hatterfigyelo.

A v10 verzio ket modon allitja be az automatikus inditast:

1. HKCU Run registry bejegyzes
2. Startup mappas parancsikon tartaleknak

Ez azert lett igy megoldva, mert egyes gepeken a Startup parancsikon onmagaban nem indul megbizhatoan.

Fontos: a beallitas utan a csomag mappajat ne helyezd at, mert az automatikus inditas az aktualis fajlhelyre mutat.

Hibaellenorzes Windows indulaskor
---------------------------------
Ha Windowszal megsem indulna a figyeles, nezd meg ezt a fajlt:

  emailopener_startup_log.txt

Ez ugyanabban a mappaban jon letre, ahol az emailopener_gui.hta van.

Tipikus hibak:

- nincs beallitott figyelendo mappa
- a beallitott mappa mar nem letezik
- a csomag mappaja at lett helyezve
- a Windows blokkolta a letoltott ZIP tartalmat

ZIP tiltasanak feloldasa
------------------------
Ha a HTA/VBS nem indul:

1. Jobb klikk a ZIP fajlon.
2. Tulajdonsagok.
3. Tiltas feloldasa / Unblock, ha van ilyen opcio.
4. Ezutan csomagold ki ujra.

Fajlok
------
emailopener_gui.hta
  Grafikus felulet.

emailopener_gui_start.vbs
  Alternativ GUI indito, ha a .hta tarsitas nem mukodik.

emailopener_hidden_start.vbs
  Rejtett hatterindito. Ezt hasznalja a GUI es a Windows automatikus inditas is.

emailopener.bat
  A tenyleges mappafigyelo motor.

emailopener.ico
  Ikon.

emailopener_config.ini
  Automatikusan jon letre. A beallitott figyelendo mappat tarolja.

exit.txt
  Ideiglenes leallitasi jelzo fajl. A Leallitas gomb hozza letre.

emailopener_startup_log.txt
  Automatikus inditas ellenorzo naplo.
