Email mappafigyelo - HTA GUI v9
================================

Cel
---
A program egy megadott mappat figyel. Ha .eml vagy .msg fajl kerul bele, akkor a fajlt atmasolja a processed almappaba, torli az eredetit, majd megnyitja a masolatot az alapertelmezett levelezoprogrammal.

Fontos valtozas a v9-ben
------------------------
A hatterfigyeles mar nem fugg a GUI ablaktol.

Ez azt jelenti:
- a GUI bezarasa NEM allitja le a figyelest
- a Windowszal inditas NEM a GUI-t inditja
- a Windowszal inditas csak a rejtett emailopener_hidden_start.vbs fajlt futtatja
- ez a VBS rejtetten inditja az emailopener.bat fajlt
- leallitani a figyelest a GUI Leallitas gombjaval lehet

Fajlok
------
emailopener_gui.hta
  A grafikus felulet.

emailopener_gui_start.vbs
  Opcionális indito a GUI-hoz, ha a .hta dupla kattintasra nem nyilik meg.

emailopener_hidden_start.vbs
  Rejtett hatterindito. Ezt hasznalja az automatikus Windows inditas.

emailopener.bat
  A mappafigyelo motor.

emailopener.ico
  Programikon.

emailopener_config.ini
  Ezt a program hozza letre. Ebben tarolja a figyelt mappa utvonalat.

exit.txt
  Ideiglenes leallito jel. A Leallitas gomb hozza letre, a BAT pedig kilepeskor torli.

Hasznalat
---------
1. Csomagold ki a ZIP-et egy allando mappaba.
2. Inditsd el: emailopener_gui.hta
3. Valaszd ki a figyelendo mappat.
4. Kattints: Figyeles inditasa.
5. A GUI bezarhato, a figyeles a hatterben tovabb fut.

Windowszal inditas
------------------
1. Nyisd meg a GUI-t.
2. Valaszd ki a figyelendo mappat.
3. Pipald be: Windowszal induljon a rejtett figyeles, GUI nelkul.

Ezutan Windows indulaskor nem a GUI jelenik meg, hanem a hatterfigyeles indul rejtetten.

Leallitas
---------
1. Nyisd meg a GUI-t.
2. Kattints: Leallitas.
3. A hatterben futo figyelo par masodpercen belul kilep.

Ha a GUI nem nyilik meg
-----------------------
Probald ezt inditani:
emailopener_gui_start.vbs

Ha ZIP-bol lett letoltve es a Windows blokkolja:
1. Jobb klikk a ZIP-en.
2. Tulajdonsagok.
3. Tiltas feloldasa / Unblock.
4. Csomagold ki ujra.

Megjegyzes
----------
A programot ne ideiglenes Letoltesek mappabol hasznald, hanem tedd egy vegleges helyre, peldaul:
C:\Tools\EmailMappafigyelo
