Email mappafigyelo GUI
======================

Fajlok:
- emailopener_gui.hta       -> grafikus felulet
- emailopener.bat           -> a tenyleges mappafigyelo motor
- email_silent_gui.vbs      -> opcionalis rejtett indito GUI nelkul

Hasznalat:
1. Tedd a harom fajlt ugyanabba a mappaba.
2. Inditsd el: emailopener_gui.hta
3. Valaszd ki a figyelendo mappat.
4. Kattints: Figyeles inditasa.
5. Ha kell, pipald be: Induljon el automatikusan a Windowszal.

Leallitas:
- A GUI-ban kattints a Leallitas gombra.
- Ez letrehoz egy exit.txt fajlt a program mappajaban, amit a batch figyelo eszrevesz es kilep.

Megjegyzes:
- A GUI HTA-t hasznal, ez Windows alatt beepitett mshta.exe-vel fut.
- A Windows automatikus inditas a felhasznalo Startup mappajaba keszit parancsikont.
